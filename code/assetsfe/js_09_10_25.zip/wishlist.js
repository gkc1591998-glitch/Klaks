/**
 * Wishlist functionality for KLAKS e-commerce website
 * Handles adding/removing products from wishlist via AJAX
 */

console.log('WISHLIST.JS LOADED - This should appear first!');

// Wishlist object
var KLAKS_Wishlist = {
    
    // Initialize wishlist functionality
    init: function() {
        this.bindEvents();
        this.updateWishlistCount();
        this.checkExistingWishlistItems();
    },
    
    // Bind click events
    bindEvents: function() {
        // Add to wishlist
        $(document).on('click', '.add_to_wishlist', this.addToWishlist);
        
        // Remove from wishlist (on product pages)
        $(document).on('click', '.remove_from_wishlist', this.removeFromWishlist);
        
        // Toggle wishlist state
        $(document).on('click', '.toggle_wishlist', this.toggleWishlist);
        
        // Clear wishlist
        $(document).on('click', '#clear-wishlist-btn', this.clearWishlist);
    },
    
    // Add product to wishlist
    addToWishlist: function(e) {
        e.preventDefault();
        
        var $this = $(this);
        var productId = $this.data('product-id') || $this.closest('.product-item').data('product-id') || $this.closest('[data-product-id]').data('product-id');
        var productMoreInfoId = $this.data('product-more-info-id') || $this.closest('[data-product-more-info-id]').data('product-more-info-id');
        
        // Try to find product ID from various sources
        if (!productId) {
            // Look for product ID in URL or other attributes
            var href = $this.attr('href');
            if (href && href.includes('product')) {
                var matches = href.match(/(\d+)/);
                if (matches) {
                    productId = matches[0];
                }
            }
        }
        
        if (!productId) {
            KLAKS_Wishlist.showMessage('Product ID not found', 'error');
            return;
        }
        
        // Check if user is logged in (you might need to adjust this check)
        if (!KLAKS_Wishlist.isUserLoggedIn()) {
            KLAKS_Wishlist.showMessage('Please login to add items to wishlist', 'error');
            return;
        }
        
        // Show loading state
        $this.addClass('loading');
        
        // Prepare data
        var data = {
            product_id: productId
        };
        
        // Add product_more_info_id if available
        if (productMoreInfoId) {
            data.product_more_info_id = productMoreInfoId;
        }
        
        // AJAX request
        $.ajax({
            url: site_url + 'Dashboard/add_to_wishlist',
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                $this.removeClass('loading');
                
                if (response.status === 'success') {
                    // Update button state
                    KLAKS_Wishlist.updateButtonState($this, true);
                    
                    // Update wishlist count
                    KLAKS_Wishlist.updateWishlistCountDisplay(response.wishlist_count);
                    
                    // Show success message
                    KLAKS_Wishlist.showMessage(response.message, 'success');
                } else {
                    KLAKS_Wishlist.showMessage(response.message, 'error');
                }
            },
            error: function() {
                $this.removeClass('loading');
                KLAKS_Wishlist.showMessage('An error occurred. Please try again.', 'error');
            }
        });
    },
    
    // Remove product from wishlist
    removeFromWishlist: function(e) {
        e.preventDefault();
        
        var $this = $(this);
        var productId = $this.data('product-id');
        var productMoreInfoId = $this.data('product-more-info-id');
        
        console.log('Remove clicked:', {
            productId: productId,
            productMoreInfoId: productMoreInfoId,
            hasRemoveClass: $this.hasClass('remove'),
            element: $this[0]
        });
        
        if (!productId) {
            KLAKS_Wishlist.showMessage('Product ID not found', 'error');
            return;
        }
        
        // Show confirmation for wishlist page removes
        if ($this.hasClass('remove') && !confirm('Are you sure you want to remove this item from your wishlist?')) {
            return;
        }
        
        // Show loading state
        $this.addClass('loading');
        
        // Prepare data
        var data = {
            product_id: productId
        };
        
        // Add product_more_info_id if available
        if (productMoreInfoId) {
            data.product_more_info_id = productMoreInfoId;
        }
        
        console.log('AJAX URL:', site_url + 'Dashboard/remove_from_wishlist');
        console.log('AJAX Data:', data);
        
        // AJAX request
        $.ajax({
            url: site_url + 'Dashboard/remove_from_wishlist',
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                console.log('Remove AJAX success:', response);
                $this.removeClass('loading');
                
                if (response.status === 'success') {
                    // Check if we're on the wishlist page
                    var $row = $this.closest('tr');
                    if ($row.length && $row.attr('id') && $row.attr('id').startsWith('wishlist-row-')) {
                        // Remove the row with animation
                        $row.fadeOut(300, function() {
                            $(this).remove();
                            // Check if no more items
                            if ($('.wishlist_table tbody tr').length === 0) {
                                location.reload(); // Reload to show empty state
                            } else {
                                // Update count in title if exists
                                $('.wishlist-title h2').text('My Wishlist on Klaks (' + response.wishlist_count + ' items)');
                            }
                        });
                    } else {
                        // Update button state for product pages
                        KLAKS_Wishlist.updateButtonState($this, false);
                    }
                    
                    // Update wishlist count
                    KLAKS_Wishlist.updateWishlistCountDisplay(response.wishlist_count);
                    
                    // Show success message
                    KLAKS_Wishlist.showMessage(response.message, 'success');
                } else {
                    KLAKS_Wishlist.showMessage(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.log('Remove AJAX error:', {
                    xhr: xhr,
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                $this.removeClass('loading');
                KLAKS_Wishlist.showMessage('An error occurred. Please try again.', 'error');
            }
        });
    },
    
        // Clear all wishlist items
    clearWishlist: function(e) {
        e.preventDefault();
        
        var $this = $(this);
        
        console.log('Clear wishlist clicked:', {
            hasClearClass: $this.hasClass('clear-wishlist'),
            element: $this[0]
        });
        
        if (!confirm('Are you sure you want to clear all items from your wishlist?')) {
            return;
        }
        
        console.log('AJAX URL:', site_url + 'Dashboard/clear_wishlist');
        
        // AJAX request
        $.ajax({
            url: site_url + 'Dashboard/clear_wishlist',
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                console.log('Clear AJAX success:', response);
                if (response.status === 'success') {
                    // Reload the page to show empty state
                    location.reload();
                } else {
                    KLAKS_Wishlist.showMessage(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.log('Clear AJAX error:', {
                    xhr: xhr,
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                KLAKS_Wishlist.showMessage('An error occurred. Please try again.', 'error');
            }
        });
    },
    
    // Toggle wishlist state
    toggleWishlist: function(e) {
        e.preventDefault();
        
        var $this = $(this);
        var isInWishlist = $this.hasClass('in-wishlist');
        
        if (isInWishlist) {
            // Remove from wishlist
            KLAKS_Wishlist.removeFromWishlist.call(this, e);
        } else {
            // Add to wishlist
            KLAKS_Wishlist.addToWishlist.call(this, e);
        }
    },
    
    // Update button state
    updateButtonState: function($button, isInWishlist) {
        if (isInWishlist) {
            $button.addClass('in-wishlist');
            $button.removeClass('add_to_wishlist').addClass('remove_from_wishlist');
            
            // Change icon to filled heart and update styling
            var $icon = $button.find('.wishlist-heart-icon');
            if ($icon.length) {
                $icon.text('♥'); // Change to filled heart
                $button.addClass('wishlist-added');
            } else {
                $button.text('♥'); // Fallback if no icon
                $button.addClass('wishlist-added');
            }
            
            $button.attr('title', 'Remove from Wishlist');
        } else {
            $button.removeClass('in-wishlist');
            $button.removeClass('remove_from_wishlist').addClass('add_to_wishlist');
            
            // Change icon back to outline heart and remove styling
            var $icon = $button.find('.wishlist-heart-icon');
            if ($icon.length) {
                $icon.text('♡'); // Change back to outline heart
                $button.removeClass('wishlist-added');
            } else {
                $button.text('♡'); // Fallback if no icon
                $button.removeClass('wishlist-added');
            }
            
            $button.attr('title', 'Add to Wishlist');
        }
    },
    
    // Update wishlist count in navigation
    updateWishlistCountDisplay: function(count) {
        $('.wishlist-count').text(count);
        $('.wishlist-counter').text(count);
        
        // Update mobile footer wishlist count if exists
        $('.device-wishlist .count').text(count);
    },
    
    // Update wishlist count on page load
    updateWishlistCount: function() {
        if (!KLAKS_Wishlist.isUserLoggedIn()) {
            return;
        }
        
        // This could be loaded from server or via AJAX
        // For now, we'll skip this as count will be updated on actions
    },
    
    // Check existing wishlist items and update button states
    checkExistingWishlistItems: function() {
        if (!KLAKS_Wishlist.isUserLoggedIn()) {
            return;
        }
        
        // Get all product IDs on the current page
        var productIds = [];
        $('.add_to_wishlist').each(function() {
            var productId = $(this).data('product-id');
            if (productId && productIds.indexOf(productId) === -1) {
                productIds.push(productId);
            }
        });
        
        if (productIds.length > 0) {
            // AJAX call to check which products are in wishlist
            $.ajax({
                url: site_url + 'Dashboard/check_wishlist_items',
                type: 'POST',
                data: {
                    product_ids: productIds
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.wishlist_items) {
                        response.wishlist_items.forEach(function(productId) {
                            var $buttons = $('.add_to_wishlist[data-product-id="' + productId + '"]');
                            $buttons.each(function() {
                                KLAKS_Wishlist.updateButtonState($(this), true);
                            });
                        });
                    }
                },
                error: function() {
                    // Silently fail - not critical
                    console.log('Could not check existing wishlist items');
                }
            });
        }
    },
    
    // Check if user is logged in
    isUserLoggedIn: function() {
        // You might need to adjust this based on your authentication system
        // This is a simple check - you can make it more robust
        return typeof user_logged_in !== 'undefined' && user_logged_in === true;
    },
    
    // Show notification message
    showMessage: function(message, type) {
        var notificationClass = type === 'success' ? 'alert-success' : 'alert-danger';
        
        // Create notification element
        var notification = $('<div class="wishlist-notification alert ' + notificationClass + '">' + message + '</div>');
        
        // Add to top of page or specific container
        var container = $('.main-content').first();
        if (container.length === 0) {
            container = $('body');
        }
        
        container.prepend(notification);
        
        // Auto hide after 3 seconds
        setTimeout(function() {
            notification.fadeOut(function() {
                $(this).remove();
            });
        }, 3000);
    }
};

console.log('BEFORE DOCUMENT READY - jQuery loaded?', typeof jQuery !== 'undefined');

// Initialize wishlist functionality when document is ready
$(document).ready(function() {
    // Set site URL if not already defined
    if (typeof site_url === 'undefined') {
        // Try to get from a global variable or construct it
        if (window.location.pathname.includes('/klaks/')) {
            site_url = window.location.origin + '/klaks/';
        } else {
            site_url = window.location.origin + '/';
        }
    }
    
    console.log('Wishlist JS: site_url =', site_url);
    console.log('Wishlist JS: user_logged_in =', typeof user_logged_in !== 'undefined' ? user_logged_in : 'undefined');
    
    // Initialize wishlist
    KLAKS_Wishlist.init();
    
    // Debug: Log available elements
    console.log('Clear wishlist button found:', $('#clear-wishlist-btn').length);
    console.log('Remove buttons found:', $('.remove-from-wishlist').length);
});

$(document).on('click', '.add_to_wishlist', KLAKS_Wishlist.addToWishlist);
$(document).on('click', '.remove-from-wishlist', KLAKS_Wishlist.removeFromWishlist);
$(document).on('click', '.toggle_wishlist', KLAKS_Wishlist.toggleWishlist);
$(document).on('click', '#clear-wishlist-btn', KLAKS_Wishlist.clearWishlist);

// CSS for wishlist notifications
$('head').append(`
<style>
.wishlist-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    padding: 15px 20px;
    border-radius: 4px;
    font-weight: 500;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.wishlist-notification.alert-success {
    background-color: #d4edda;
    border-color: #c3e6cb;
    color: #155724;
}

.wishlist-notification.alert-danger {
    background-color: #f8d7da;
    border-color: #f5c6cb;
    color: #721c24;
}

.add_to_wishlist.loading::after {
    content: " Loading...";
    font-size: 0.9em;
    color: #999;
}

.yith-wcwl-add-to-wishlist .loading {
    opacity: 0.6;
    pointer-events: none;
}
</style>
`);
