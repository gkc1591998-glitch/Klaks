$(document).ready(function () {
  function updateCartQty(btn, delta) {
    var container = btn.closest(".counter-container");
    var valueInput = container.querySelector(".counter-value input");
    var quantity = parseInt(valueInput.value);
    if (isNaN(quantity)) quantity = 1;
    quantity += delta;
    if (quantity < 1) quantity = 1;
    valueInput.value = quantity;

    // Gather info
    var parent = btn.closest(".mx-3");
    var size = parent.querySelector(".product_size").value;
    var id = parent.querySelector(".product_id").value;
    var rowId = parent.querySelector(".cart_row_id").value;
    var price = parent.querySelector(".product_price").value;

    // Ajax update
    jQuery.ajax({
      type: "POST",
      url: "<?php echo site_url(); ?>cart/updatecart",
      data: {
        qty: quantity,
        rowId: rowId,
        price: price,
      },
      complete: function (data) {
        console.log("Cart updated:", data);
        var op = data.responseText.trim();
        jQuery("#cartid").html(op);
      },
    });
  }

  function deletecartcheckout(valu) {
    // alert(valu);
    jQuery.ajax({
      type: "POST",
      url: "<?php echo site_url(); ?>cart/deletecart",
      data: "valu=" + valu,
      complete: function (data) {
        var op = data.responseText.trim();
        jQuery("#cartid").html(op);
      },
    });
  }

  function deletecart(valu) {
    jQuery.ajax({
      type: "POST",
      url: "<?php echo site_url(); ?>products/deletecart",
      data: "valu=" + valu,
      complete: function (data) {
        var op = data.responseText.trim();
        jQuery("#cartdivid").html(op);
      },
    });
  }
});
