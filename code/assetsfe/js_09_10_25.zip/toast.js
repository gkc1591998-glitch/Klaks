/* Small toast utility (no external dependency) */
(function(window, document){
  'use strict';
  function ensureContainer(){
    var id = 'appToastContainer';
    var c = document.getElementById(id);
    if (!c) {
      c = document.createElement('div');
      c.id = id;
      c.className = 'app-toast-container';
      c.setAttribute('aria-live','polite');
      c.setAttribute('aria-atomic','true');
      document.body.appendChild(c);
    }
    return c;
  }

  window.showToast = function(message, options){
    options = options || {};
    var type = options.type || 'info';
    var timeout = typeof options.timeout === 'number' ? options.timeout : 3500;
    var container = ensureContainer();
    if (!container) return null;
    var el = document.createElement('div');
    el.className = 'app-toast type-' + (type || 'info');
    if (type === 'success') {
      el.style.borderLeft = '4px solid rgba(255,255,255,0.12)';
    } else if (type === 'error') {
      el.style.borderLeft = '4px solid rgba(255,255,255,0.12)';
    } else {
      el.style.borderLeft = '4px solid rgba(255,255,255,0.06)';
    }
    var body = document.createElement('div');
    body.className = 'app-toast-body';
    body.textContent = message || '';
    var closeBtn = document.createElement('button');
    closeBtn.className = 'app-toast-close';
    closeBtn.setAttribute('aria-label','close');
    closeBtn.textContent = '×';
    el.appendChild(body);
    el.appendChild(closeBtn);
    container.appendChild(el);
    // allow transition
    setTimeout(function(){ el.classList.add('show'); }, 10);
    var remove = function(){
      el.classList.remove('show');
      setTimeout(function(){ try{ container.removeChild(el); }catch(e){} }, 260);
    };
    closeBtn.addEventListener('click', remove);
    if (timeout > 0) setTimeout(remove, timeout);
    return el;
  };

})(window, document);
